## [1.0.7] - 2018-7-24
### Added
- Gyro support